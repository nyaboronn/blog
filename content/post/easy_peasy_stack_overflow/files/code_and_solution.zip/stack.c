#include <stdio.h>

void call_me() {
	printf("You cannot call me, noob!\n");
}

void parse_file(char* filename){
	char url[16];
	char buffer[512];

	printf("Abriendo fichero %s ...\n", filename);

	FILE *f = fopen(filename, "r");
	if(f == NULL){
		printf("Fallo al abrir el fichero :(\n");
		return;
	}
	printf("Leyendo fichero %s ...\n", filename);

	fread(buffer, 1, 256, f);
	printf("Fichero leido! Contenido: \n");
	//printf(buffer);

	printf("\nBuscando URL en el fichero..\n");

	char* url_start = strstr(buffer, "http://");
	if(url_start == NULL){
		printf("URL no encontrada :(\n");
		return;
	}

	memcpy(url, url_start, 512);

	printf("URL: %s\n", url);

	fclose(f);
	return;
}

int main(int argc, char** argv) {
	if(argc != 2){
		printf("Uso: %s <fichero>\n", argv[0]);
		return -1;
	}

	parse_file(argv[1]);
	return 0;
}